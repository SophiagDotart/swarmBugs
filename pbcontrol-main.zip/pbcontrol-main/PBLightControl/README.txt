Code to control single LEDs of the ESP according to the schematic through the monitor in ESP_IDF


How this code works:
    1. open ESP-IDF and create a project named "PBLightControl"
    2. cd main
    3. replace the "PBLightControl.c" with the uploaded code
