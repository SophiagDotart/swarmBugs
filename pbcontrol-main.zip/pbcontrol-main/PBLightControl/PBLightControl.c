#include <stdio.h>
#include <string.h>
#include "esp_system.h"
#include "esp_console.h"
#include "esp_vfs_dev.h"
#include "esp_vfs_fat.h"
#include "driver/uart.h"
#include "driver/ledc.h"
#include "esp_err.h"

#define led1 05     //red; problem
#define led2 26     //yellow; idle
#define led3 4     //white; connected 
#define led4 25     //green; done 
#define led5 33     //blue; building

void LEDSetup(){
    gpio_set_direction(led1, GPIO_MODE_OUTPUT);
    gpio_set_direction(led2, GPIO_MODE_OUTPUT);
    gpio_set_direction(led3, GPIO_MODE_OUTPUT);
    gpio_set_direction(led4, GPIO_MODE_OUTPUT);
    gpio_set_direction(led5, GPIO_MODE_OUTPUT);
}
void turnOff(){
    //turn leds off
    gpio_set_level(led1, 0);
    gpio_set_level(led2, 0);
    gpio_set_level(led3, 0);
    gpio_set_level(led4, 0);
    gpio_set_level(led5, 0);
}

void shine(char blinkLed){
    turnOff();
    gpio_set_level(blinkLed, 1);
}

void app_main(void)
{  
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    ESP_ERROR_CHECK(uart_driver_install(CONFIG_ESP_CONSOLE_UART_NUM, 256, 0, 0, NULL, 0));
    esp_vfs_dev_uart_use_driver(CONFIG_ESP_CONSOLE_UART_NUM);
    esp_vfs_dev_uart_port_set_rx_line_endings(CONFIG_ESP_CONSOLE_UART_NUM, ESP_LINE_ENDINGS_CR);
    esp_vfs_dev_uart_port_set_tx_line_endings(CONFIG_ESP_CONSOLE_UART_NUM, ESP_LINE_ENDINGS_CRLF);

    LEDSetup();
    int led = 0;

    printf("Enter the number of the LED you'd like to light up!\n");
    printf("1 = red/problem; 2 = yellow/idle; 3 = white/connected; 4 = green/done; 5 = blue/building; else = turn off all\n");
    
    while(1){
        printf("Enter Data : ");
        scanf("%d", &led);
        if(led == 1){
            shine(led1);
        }
        else if(led == 2){
            shine(led2);
        }
        else if(led == 3){
            shine(led3);
        }
        else if(led == 4){
            shine(led4);
        }
        else if(led == 5){
            shine(led5);
        }
        else{
            turnOff();
        }
        printf("\nData entered : %d\n", led);

        
    }
}
