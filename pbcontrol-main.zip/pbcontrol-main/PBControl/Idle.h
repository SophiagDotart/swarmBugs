#ifndef HEADER_IDLE
#define HEADER_IDLE

extern void idle();
//extern variableType variable ->avoid

#endif
