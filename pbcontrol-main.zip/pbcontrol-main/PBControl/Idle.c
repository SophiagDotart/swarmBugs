/*idle control script
aimlessly drive around until connection secured
*/

#include <stdio.h>
//#include "esp_log.h"
#include "Idle.h"
#include "HardwareControl/LEDControl.h"
#include "Movement.h"
#include "Connect.h"
#include "MQTTConnect.h"

void idle(){
    shine('led2');
    while(connectionEstablished() == 0){
            idleMovement();
    }
    while(connectionEstablished() == 1){
        if (getGoalPos(0) != 0){
            buildStructure();
        }
    }
    
    
    
 }
