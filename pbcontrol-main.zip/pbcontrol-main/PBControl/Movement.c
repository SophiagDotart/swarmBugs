/*Script to control the way the bug moves
    ->implement distance control 
*/
#include <stdio.h>
#include "HardwareControl/FindPosition.h"
#include "HardwareControl/Motors.h"
#include "ProblemHappened.h"

void dirMove(int angle){
    int change = getCurAngle() - angle;

    int change = change - angle;
    if(angle > 0 && angle <= 180){          //turn right
        turnOnSpotLeft(change);
    }
    else if(angle > 180 && angle <= 360){   //turn left
        turnOnSpotLeft(change);
    }
    else{                                   //default forward; may cause errors
        forward();
    }
}

void goToPos (int coordinates[]){ 
    if (getCurPos(0) == 0){
        if(getCurPos(1) == 0){
            //if(getCurPos(2) == 0){ //only 3D
                posSensorNotReading();
                //for some reason, concatination is not accepted
            //}
        }
            
    }
    //Input coordinates^-1 = [goalX, goalY, goalZ]; same pattern for getCurPos()
    int diffGoalCurX = coordinates[0] - getCurPos(0);
    int diffGoalCurY = coordinates[1] - getCurPos(1);

    int straightDistToGoal = (int) sqrt(diffGoalCurX*diffGoalCurX + diffGoalCurY*diffGoalCurY);
    int angleToGoal = asin(diffGoalCurX/straightDistToGoal);

    //actually go to that pos for 2D
    dirMove(angleToGoal);
    forward(straightDistToGoal);
    //climbToPos(straightDistToGoal, angleToGoal, coordinates[2]); for 3D
}

void idleMovement(){

}

void avoidCollition(){
    //don't crash please!
}

void climb(){
    //function if extra power is needed for climbing; 3D
} 
