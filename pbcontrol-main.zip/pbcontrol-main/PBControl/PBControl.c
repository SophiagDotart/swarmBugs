#include <stdio.h>
#include "Idle.h"
#include "HardwareControl/Motors.h"
#include "HardwareControl/LEDControl.c"
#include "HardwareControl/DistanceSensors.h"
#include "HardwareControl/FindPosition.h"


void app_main(void)
{
    motorSetup();
    LEDSetup();
    posSetup();
    distSetup();
    i2c_master_init();

    while(true){
        idle();
    }
    
}
