#ifndef HEADER_MOVEMENT
#define HEADER_MOVEMENT

extern void dirMove(int angle);
extern void goToPos (int coordinates[]);
extern void idleMovement();
extern void avoidCollition();
extern void climb();

#endif
