#ifndef HEADER_MOTORS
#define HEADER_MOTORS

void motorSetup(){};
void forward(){};
void backward(){};
void stop(){};
void turnOnSpotRight(int angle){};
void turnOnSpotLeft(int angle){};

#endif
