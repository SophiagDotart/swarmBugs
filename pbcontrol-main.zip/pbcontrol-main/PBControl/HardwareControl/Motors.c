/*script to control the motors
just the basic functions; at first without pwm to keep it simple and have sth working quickly
*/
//include standart libraries
#include <stdio.h>
#include "Drivers/gpio.h"
#include "sdkconfig.h"

#define motor1a 12  //left motor
#define motor1b 25
#define enable1 14  //enable for left motor
#define motor2a 27  //right motor
#define motor2b 33
#define enable2 13  //enable for right motor


void motorSetup(){
	gpio_set_direction(motor1a, GPIO_MODE_OUTPUT);	//attach the motors
    gpio_set_direction(motor1b, GPIO_MODE_OUTPUT);
	gpio_set_direction(enable1, GPIO_MODE_OUTPUT);
	gpio_set_direction(motor2a, GPIO_MODE_OUTPUT);
    gpio_set_direction(motor2b, GPIO_MODE_OUTPUT);
	gpio_set_direction(enable2, GPIO_MODE_OUTPUT);
}

void forward(){ //turn both motors with same speed
    //setSpeed(50, 1);
    //setSpeed(50, 2);
	gpio_set_level(motor1a, 1);
    gpio_set_level(motor1b, 0);
	gpio_set_level(motor2a, 1);
    gpio_set_level(motor2b, 0);
	vTaskDelay(50/portTICK_PERIOD_MS); //to get to ms use portTICK_PERIOD_MS function
}	//https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/system/freertos_idf.html?highlight=pdms_to_ticks

void backward(){ //turn both motors with same speed in opposite direction
    //setSpeed(-50, 1);
    //setSpeed(-50, 2);
    gpio_set_level(motor1a, 0);
    gpio_set_level(motor1b, 1);
	gpio_set_level(motor2a, 0);
    gpio_set_level(motor2b, 1);
}

void stop(){
    //setSpeed(0, 1);
    //setSpeed(0, 2);
    gpio_set_level(motor1a, 0);
    gpio_set_level(motor1b, 0);
    gpio_set_level(motor2a, 0);
    gpio_set_level(motor2b, 0);
    vTaskDelay(50/portTICK_PERIOD_MS);
}

void turnOnSpotRight(int angle){
    //convert angle to ticks negative ->map
	gpio_set_level(motor2a, 0);
    gpio_set_level(motor2b, 0);
	gpio_set_level(motor1a, 1);
    gpio_set_level(motor1b, 0);
	//vTaskDelay(50/portTICK_PERIOD_MS);
    //vTaskDelay(50/portTICK_PERIOD_MS);
    for(int i = 0; i <= ticks; ++i){
        vTaskDelay(1);
    }
}

void turnOnSpotLeft(int angle){
    //convert angle to ticks ->map
	gpio_set_level(motor1b, 0);
    gpio_set_level(motor1a, 0);
	gpio_set_level(motor2a, 1);
    gpio_set_level(motor2b, 0);
	//vTaskDelay(50/portTICK_PERIOD_MS);
    for(int i = 0; i <= ticks; ++i){
        vTaskDelay(1);
    }
}
