/* Script to find the current position
    -> currently implemented: MPU6050 gyroscope
    -> code adapted from the official ESP exapmle library and can be viewed under:
        https://github.com/espressif/esp-idf/tree/master/examples 
*/
#include <stdio.h>
#include "Drivers/esp_log.h"
#include "Drivers/i2c.h"
#include "FindPosition.h"
#include "Math.h"

#define I2C_MASTER_SCL_IO           22      /*!< GPIO number used for I2C master clock */
#define I2C_MASTER_SDA_IO           21      /*!< GPIO number used for I2C master data  */
#define I2C_MASTER_NUM              0       /*!< I2C master i2c port number, the number of i2c peripheral interfaces available will depend on the chip */
#define I2C_MASTER_FREQ_HZ          400000  /*!< I2C master clock frequency */
#define I2C_MASTER_TX_BUF_DISABLE   0       /*!< I2C master doesn't need buffer */
#define I2C_MASTER_RX_BUF_DISABLE   0       /*!< I2C master doesn't need buffer */
#define I2C_MASTER_TIMEOUT_MS       1000

#define MPU6050_SENSOR_ADDR                 0x68        /*!< Slave address of the MPU9250 sensor */
#define MPU6050_WHO_AM_I_REG_ADDR           0x75        /*!< Register addresses of the "who am I" register */

#define MPU6050_PWR_MGMT_1_REG_ADDR         0x6B        /*!< Register addresses of the power managment register */
#define MPU6050_RESET_BIT                   7

int curAngle; //new variable defined
int * pMpu;
float acce_sensi[3]; 
float gyro_sensi[3];


/**
 * @brief i2c master initialization
 */
static esp_err_t i2c_master_init(void)
{
    int i2c_master_port = I2C_MASTER_NUM;

    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = I2C_MASTER_SDA_IO,
        .scl_io_num = I2C_MASTER_SCL_IO,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = I2C_MASTER_FREQ_HZ,
    };

    i2c_param_config(i2c_master_port, &conf);

    return i2c_driver_install(i2c_master_port, conf.mode, I2C_MASTER_RX_BUF_DISABLE, I2C_MASTER_TX_BUF_DISABLE, 0);
}

void posSetup(){
    ESP_ERROR_CHECK(i2c_master_init());

    uint8_t MPUdata[5]={0};
    mpu6050_handle_t mpu;
    mpu = mpu6050_create(0, MPU6050_SENSOR_ADDR);
    pMpu = &mpu;
    ESP_ERROR_CHECK(mpu6050_config(mpu, ACCE_FS_8G, GYRO_FS_500DPS));
    mpu6050_wake_up(mpu);

    mpu6050_get_deviceid(mpu,MPUdata);
    //ESP_LOGI(TAG, "QUIEN_SOY= %X", MPUdata[0]);

    //float acce_sensi[3]; //used to be used for storing; now replaced through pointers
    //float gyro_sensi[3];
    curAngle = 0;
}

int getCurPos(int a){
    mpu6050_get_acce(*pMpu, acce_sensi); 
    vTaskDelay(600 / portTICK_PERIOD_MS);	//for internal stability
    int position[3];
    //doubleIntegrate(acce_sensi[x]); implement as soon as function fully functioning
    //as it is, it is returning the acceleration, not the position
    //Input position^-1 = [X, Y, Z];
    if (a == 0){
        return *(acce_sensi[0]); //x-Axis
    }
    else if(a == 1){
        return position[1]; //y-Axis
    }
    else{
        return position[2]; //z-Axis, height
    }
    return (-1);
}

int getCurAngle(int a){ //Store the change of the angle in gyro_sensi[x,y,z]
    //mpu6050_get_gyro(mpu, gyro_sensi); //original
    mpu6050_get_gyro(*pMpu, gyro_sensi);
    vTaskDelay(600 / portTICK_PERIOD_MS); 
    //the gyroscope will be mounted vertically, as such the x-Value is the only one currently needed
    ///if (a == 0){
    return updatePos(doubleIntegrate(gyro_sensi[0])); //x-Axis; angle the bug's facing
    /*}
    else if(a == 1){
        return gyro_sensi[1]; //y-Axis
    }
    else{
        return gyro_sensi[2]; //z-Axis, height
    }*/
    return (-1);
}

int updatePos(int a){ //currently only implemented in 2d
    if(a > 0){
        return curAngle = curAngle + (int)a;
    }
    else{
        return curAngle = curAngle - (int)a;
    }
}
