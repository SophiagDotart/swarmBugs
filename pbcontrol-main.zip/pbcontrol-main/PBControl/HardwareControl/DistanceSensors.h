#ifndef HEADER_DISTSENSORS
#define HEADER_DISTSENSORS

extern void distSetup();

#endif
