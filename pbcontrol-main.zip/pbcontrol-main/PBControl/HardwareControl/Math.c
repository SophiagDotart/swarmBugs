/* Script defining mathmatic functions
*/
#include <stdio.h>

double prevVelocity = 0;
double prevPos = 0;
double previousTime = 0;
double velocity = 0;
double moved = 0;

int integrate(int a){
    //Still testing
    int b;
    return b;
}

int doubleIntegrate(double accsel){//convert acceleration to curPos 
    unsigned long currentTime = millis();                       // Get current time
    unsigned long elapsedTime = currentTime - previousTime;     // Calculate elapsed time since the last calculation
    double timeChange = (double)elapsedTime / 1000.0;           // timeshift
  
    velocity += accsel * timeChange + prevVelocity;      // Update velocity using the current acceleration and elapsed time
    moved += velocity * timeChange + prevPos;            // Update position using the current velocity and elapsed time
  
    *previousTime = currentTime;
    *prevPos = moved;
    *prevVelocity = velocity;

    return (int)moved;
}
