/*script for direct control over the distance sensors
current sensors configured: Arduino-Standart
    ->implement properly
*/

#include <stdio.h>

void distSetup(){
    //import from testing envirnoment
}
