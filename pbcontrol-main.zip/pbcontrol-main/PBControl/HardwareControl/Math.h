#ifndef HEADER_MATH
#define HEADER_MATH

extern double prevVelocity;
extern double prevPos;
extern double previousTime;
extern double velocity;
extern double moved;
extern int integration(int a){};
extern int doubleIntegrate(double a){};

#endif