/* Skript to control all LEDs
    ->Debugging LEDs implemented
    -> implement the one's for show  
*/

#include <stdio.h>
#include "Drivers/gpio.h"
#include "driver/uart.h"
#include "driver/ledc.h"
#include "esp_err.h"

//Setting the output pins for the LEDs
#define led1 05     //red; problem
#define led2 26     //yellow; idle
#define led3 4     //white; connected 
#define led4 25     //green; done 
#define led5 33     //blue; building

void LEDSetup(){
    gpio_set_direction(led1, GPIO_MODE_OUTPUT);
    gpio_set_direction(led2, GPIO_MODE_OUTPUT);
    gpio_set_direction(led3, GPIO_MODE_OUTPUT);
    gpio_set_direction(led4, GPIO_MODE_OUTPUT);
    gpio_set_direction(led5, GPIO_MODE_OUTPUT);
}
void turnOff(){
    //turn leds off
    gpio_set_level(led1, 0);
    gpio_set_level(led2, 0);
    gpio_set_level(led3, 0);
    gpio_set_level(led4, 0);
    gpio_set_level(led5, 0);
}

void shine(char blinkLed){
    turnOff();
    // Set the GPIO level according to the state
    gpio_set_level(blinkLed, 1);
}

void changeLEDShowType(){
    //insert control for the optional LEDs here
}
