#ifndef HEADER_LEDControl
#define HEADER_LEDControl

extern void LEDSetup();
extern void turnOff();
extern void shine(char blinkLed);
extern void changeLEDShowType();

#endif
