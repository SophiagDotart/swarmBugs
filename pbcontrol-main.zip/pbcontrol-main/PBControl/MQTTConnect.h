#ifndef HEADER_MQTTCONNECT
#define HEADER_MQTTCONNECT

extern void unpack(char a);
extern int getGoalPos();
extern int connectionEstablished();
extern void getMessage();

#endif
