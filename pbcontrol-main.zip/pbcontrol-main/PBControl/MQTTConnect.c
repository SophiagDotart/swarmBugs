/* Communication management script
    -> include code from the other groups here!
    -> change the return type to pointer (efficiancy and easy access throuout document)
*/
#include <stdio.h>

void unpack(char a){
    return a;
}

/*void retPosToZI(int[]){
    //
}*/

int getGoalPos(){ //change this using pointers to not return array!!!
    int coordinates[3];
    return;
} //Update using the Gyroscopes code as an example!

int connectionEstablished(){
    int connected = 1; //XXX adapt later
    if (connected == 1){
        return 1;
    }
}

void getMessage(){
    if(/*unplausible*/){
        //instructionIncorrect();
    }
}
