How to make this code work:

1. install esp-idf on your computer

2. create a new project named "PBControl"

3. copy the code into the main folder (*.c, *.h HardwareControl)
    make sure to only copy the code in PBControl into the pre-existing file!
    the content CMakeList file has to be copied into the existing file separately! 

Further read:

Documentation Hardwarekompatibilität

Debugging Compilation

