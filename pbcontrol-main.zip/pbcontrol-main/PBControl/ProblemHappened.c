/*script to try and solve problems on the go
    -> figue out which pin number is rst pin
*/
#include <stdio.h>
#include "HardwareControl/Motors.h"
#include "HardwareControl/FindPosition.h"
#include "HardwareControl/LEDControl.h"
#include "Movement.h"
#include "MQTTConnect.h"

void posSensorNotReading(){
    stop();
    shine('led1');
    //set reset pin to HIGH
    //gpio_set_level(rstPin, 1);
    if (getCurPor(0) == 0){     //this weird
        if(getCurPor(1) == 0){
            //if(getCurPos(2) == 0){ //only 3D
                goToPos((-1)*getGoalPos(0), (-1)*getGoalPos(1)); //return to home
                //for some reason, concatination is not accepted
            //}
        }
    }
}
