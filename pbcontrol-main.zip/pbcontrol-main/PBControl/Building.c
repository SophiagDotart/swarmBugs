/*script to make sure swarm always adapts to new conditions while building
    -> check if correct LED
*/
#include <stdio.h>
#include "Movement.h"
#include "MQTTConnect.h"
#include "HardwareControl/FindPosition.h"
#include "HardwareControl/Motors.h"

void build(){
    shine('led4');
    if(coordinatesReceived() == 0){
        idleMovement();
    }
    while(getCurPos() != getGoalPos()){
        gotToPos(getGoalPos());
    }
    shine('led5');
    stop();
    while(connectionEstablished()){
        listen();
    }
    idleMovement();
}

