#ifndef HEADER_BUILDING
#define HEADER_BUILDING

extern void build();

#endif
