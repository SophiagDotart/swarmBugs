/* Communication management script
    -> change the return type to pointer (efficiancy and easy access throuout document)
*/
#include <stdio.h>
#include <stdbool.h>
#include <ctype.h> //to check whether message is letter or number
#include "HardwareControl/Motors.h"
#include "Movement.h"
#include "Connections/CommandLineControl.h"
#include "Connections/MQTTConnect.h"

/*void retPosToZI(int[]){
    //
}*/
int getGoalPos(int a){ //change this using pointers to not return array!!!
    int coordinates[3] = {0, 0, 0};
    if (a == 0){
        return coordinates[0]; //x-Axis
    }
    else if(a == 1){
        return coordinates[1]; //y-Axis
    }
    else{
        return coordinates[2]; //z-Axis, height, 3D
    }
} //Update using the Gyroscopes code as an example!

bool coordinatesReceived(){
    if (getGoalPos(0) == 0){
        if(getGoalPos(1) == 0){
            //if(getGoalPos(2) == 0){
                return false;
            //}
        }
    }
    return true;
}

bool connectionEstablished(){
    int connected = 1; // adapt later
    if (connected == 1){
        return true;
    }
    return false;
}

void listen(){
    stop(); 
    while(coordinatesReceived() == false){
        if(connectionEstablished() == true){
            return;
        }
        listen();
    }
}

void getMessage(char command){
    //add an if for unreadable here but define rules first
        //instructionIncorrect();
    if(isalpha(command)){ //if command is to unbild structure
        if (command == "U"){
            goToPos(getGoalPos(0), getGoalPos(1)); //go back to starting position
        }
        //else its non valid input        
    }
    else if(isdigit(command)){
        getGoalPos(0);
        goToPos(getGoalPos(0), getGoalPos(1));
    }
    else{
        listen();
    }
}
