#ifndef HEADER_MQTTCONNECT
#define HEADER_MQTTCONNECT

#include <stdbool.h>

extern char unpack(char a);
extern int getGoalPos();
extern bool connectionEstablished();
extern void getMessage();
extern void listen();
extern bool coordinatesReceived();

#endif
